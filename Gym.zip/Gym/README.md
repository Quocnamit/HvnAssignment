GYM with UNIT TEST - Khiem Huynh
----------------------------------------------
CONFIGURATION
Install NodeJS
npm install -g karma-cli
npm install karma jasmine karma-jasmine --save-dev
npm install karma-chrome-launcher --save-dev

-----------------------------------------------
RUN UNIT TEST
Run all test cases:
karma start

Run a specific test suite:
Rename describe -> fdescribe

-----------------------------------------------
REQUIREMENTS:
Exercises 01: Implement Person and Student to pass their unit tests
Exercises 02: Implement Factory and its unit test