describe("Student constructor function suite", function() {
    var options;

    beforeEach(function() {
        options = {
            girlType: "smart",
            firstName: "Thuy"
        }
    });

    it("should be a constructor function", function() {

    });

    it("should have createGirl(options) function", function() {

    });

    it("should return an instance of Person when calling createGirl, if girlClass is normal", function() {

    });

    it("should return an instance of Student when calling createGirl, if girlClass is smart", function() {
        options.subject = 'Unit test';

    });
});

